/* Saya berterimakasih Kepada Penyedia Api */
const api = require("caliph-api"); // https://www.npmjs.com/package/caliph-api
const xa = require('xfarr-api')

// REST-API
// (1) pecundang.herokuapp.com => Benny

module.exports = { api, xa }

// [❗] JANGAN UBAH APA APA DISINI!